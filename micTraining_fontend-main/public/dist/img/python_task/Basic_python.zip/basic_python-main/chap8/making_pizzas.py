# import pizza

# pizza.make_pizza('mushrooms',size=16)
# pizza.make_pizza('mushrooms','green peppers','cheese',size=12)

# import pizza as p

# p.make_pizza('mushrooms',size=16)
# p.make_pizza('mushrooms','green peppers','cheese',size=12)


from pizza import make_pizza

make_pizza('mushrooms',size=16)
make_pizza('mushrooms','green peppers','cheese',size=12)

# from pizza import *
# make_pizza('mushrooms',size=16)
# make_pizza('mushrooms','green peppers','cheese',size=12)

# from pizza import make_pizza as mp

# mp('mushrooms',size=16)
# mp('mushrooms','green peppers','cheese',size=12)