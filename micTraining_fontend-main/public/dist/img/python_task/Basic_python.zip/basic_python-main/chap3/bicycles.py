#simple lists
bicycle = "trek"
bicycles = ["trek","cannonle","redline","specialized"]

print(bicycles[0].title())
print(bicycles[1].upper())
print(bicycles[2].lower())
print(bicycles[-1])
print(bicycles[-2])

print(f"My first bicycle was a {bicycles[0].title()}")