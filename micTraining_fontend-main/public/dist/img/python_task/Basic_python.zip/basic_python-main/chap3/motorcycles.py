motorycycles = ['honda','yamaha','suzuki']
print(motorycycles)

#change value lists
motorycycles[0] = 'ducati'
print(motorycycles)

motorycycles[-1] = 'vespa'
print(motorycycles)

#add more value
motorycycles.append('bmw')
print(motorycycles)