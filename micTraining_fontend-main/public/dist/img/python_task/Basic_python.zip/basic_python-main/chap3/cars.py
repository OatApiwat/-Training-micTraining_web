#Permanently sort
cars = ['bmw','audi','toyota','subaru']
print("Here is the original list:")
print(cars)

# cars.sort()
# print(cars)

# cars.sort(reverse=True)
# print(cars)

#temoirarily sorted
# print("\nHere is the sorted list:")
# print(sorted(cars))

# print("\n Here is the original list again:")
# print(cars)

#reverse list
# cars.reverse()
# print(cars)

# #count the lenght of a list
# print(f"lenght of list :{len(cars)}")


#avid error
#print(cars[5])

#empty = []
#print(empty[1])

