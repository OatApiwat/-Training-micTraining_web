message = "Hello python"

print(message)

