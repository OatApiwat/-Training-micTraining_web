print("python")
print("\tPython")
print("\t\tPython")

print("Languages:\nPython\nC")

print("\tLanguages:\n\tPython\nC")