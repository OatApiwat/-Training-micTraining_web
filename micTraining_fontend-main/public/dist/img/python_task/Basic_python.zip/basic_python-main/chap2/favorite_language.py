favorite_language = " python "

favorite_language.rstrip()
print(favorite_language)

favorite_language.lstrip()
print(favorite_language)

favorite_language.strip()
print(favorite_language)