#constants varaible
MAX_CONNECTIONS = 4000

#name
first_name = "Suraphop"
last_name = "Bunsawat"
middle_name = "D"

full_name = f"{first_name} {middle_name} {last_name}"

print(full_name)

'''assign multiple names'''
first_name,last_name,middle_name = "Suraphop","Bunsawat","D"
print(full_name)

