name = "suraphop bunsawat"
print(name)

print(name.title())

print(name.upper())

print(name.lower())