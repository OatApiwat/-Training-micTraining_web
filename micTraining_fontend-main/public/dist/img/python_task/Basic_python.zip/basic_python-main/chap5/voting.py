# age = 10

# #simple if-statement
# if age >= 18:
#     print("You are old enough to vote!")

# #if-else statement
# if age >= 18:
#     print("You are old enough to vote!")
# else:
#     print("Sorry, you are too young to vote!")

# #if-elif-else chain
# age = 12

# if age < 4:
#     print('4')
# elif age <8:
#     print('8')
# else:
#     print('else')

# # multiple elif blocks
# age = 12

# if age < 4:
#     print('4')
# elif age <8:
#     print('8')
# elif age <10:
#     print('10')
# else:
#     print('else')

#omit else blocks
age = 12 
if age < 4:
    print('4')
elif age <8:
    print('8')
elif age <10:
    print('10')

