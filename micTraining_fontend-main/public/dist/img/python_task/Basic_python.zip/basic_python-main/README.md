# Course detail
basic python course#1
date: 19-20 nov 2021

cr. suraphop bunsawat