#list
# dimensions = [200,50]
# dimensions[0] = 250
# print(dimensions)


#tuple
dimensions = (200,50)
#dimensions[0] = 250

for dimension in dimensions:
    print(dimension)


dimensions = (400,100)
print('modified dimensions :')
for dimension in dimensions:
    print(dimension)
