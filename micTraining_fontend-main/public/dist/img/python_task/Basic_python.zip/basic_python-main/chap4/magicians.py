# cats = []
# for cat in cats:

# list_of_items = []
# fot item in list_of_items:

magicians = ['alice','david','carolina']

for magician in magicians:
    #print(magician)    
    print(f"{magician.title()}, that was a great trick!")
    print(f"I can't wait to see your net trick, {magician.title()}.\n")

print("Thank you, everyone.")








