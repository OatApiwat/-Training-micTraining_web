user_0 ={
    'username':'j6639',
    'first':'Suraphop',
    'last':'Bunsawat'
}

# print(user_0)

#All key-values
# for key,value in user_0.items():
#     print(f"\nKey: {key}")
#     print(f"Value: {value}")

# #only keys
# for key in user_0.keys():
#     print(f"\nKey: {key}")

# for key in user_0:
#     print(f"\nKey: {key}")


#only values
for value in user_0.values():
    print(f"\n Value: {value}")
