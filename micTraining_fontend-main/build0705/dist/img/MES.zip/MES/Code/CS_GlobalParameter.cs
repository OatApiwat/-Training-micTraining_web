﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_CS_WinApp
{
    class CS_GlobalParameter
    {
        public static string connectionString = @"Data Source=10.121.1.95\MIC_SQL; User ID=sa;Password=mic@admin;Connection Timeout=50;";
        public static SqlConnection str_connection = new SqlConnection(@"Server=10.121.1.95\MIC_SQL; User ID=sa;Password=mic@admin;Connection Timeout=50;");
        public static void fillDataToDataGrid(DataGridView targetDataGridView, string sqlCommandStr)
        {
            var ManpowerBindingSource = new BindingSource();
            ManpowerBindingSource.DataSource = CS_GlobalParameter.GetData(sqlCommandStr);
            targetDataGridView.DataSource = ManpowerBindingSource;
        }



        public static DataTable GetData(string sqlCommand)
        {
            var DBConnection = new SqlConnection(connectionString);
            var command = new SqlCommand(sqlCommand, DBConnection);
            var adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            var table = new DataTable();
            table.Locale = CultureInfo.InvariantCulture;
            adapter.Fill(table);
            return table;
        }


        public static void getListComboBox(ComboBox targetComboBox, string txtQry, bool AddAll)
        {

            // Set parameter
            //var con = new SqlClient.SqlConnection();
            var con = new SqlConnection();
            SqlCommand command;
            try
            {
                // Get data from SQL to SQL_reader
                con.ConnectionString = connectionString;
                con.Open();
                command = new SqlCommand(txtQry, con);
                SqlDataReader rdr = command.ExecuteReader();

                    // Set defult cbo
                    targetComboBox.Items.Clear();
                    if (AddAll)
                    {
                        targetComboBox.Items.Add("All");
                    }

                    // Add data from SQL_reader to cbo
                    while (rdr.Read())
                        targetComboBox.Items.Add(rdr[0]);


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                // Close connection
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }




        public static string getSQLData(string txtQry)
        {
            // Set parameter
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            SqlCommand command;
            string returnString = "o8uyrthjfjyj";

            try
            {
                // Get data from SQL to SQL_reader
                con.ConnectionString = connectionString;
                con.Open();
                command = new SqlCommand(txtQry, con);
                SqlDataReader rdr = command.ExecuteReader();


                    // Add data from SQL_reader to cbo
                    while (rdr.Read()) ;
                returnString = rdr[0].ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error getSQLData");
            }
            finally
            {
                // Close connection
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return returnString;
        }

        public static bool CheckBoxDup(string txtQry)
        {
            // Set parameter
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            SqlCommand command;
            string sqlValue = "";
            try
            {
                // Get data from SQL to SQL_reader
                con.ConnectionString = CS_GlobalParameter.connectionString;
                con.Open();
                command = new SqlCommand(txtQry, con);
                SqlDataReader rdr = command.ExecuteReader();
                while (rdr.Read())
                {
                    sqlValue = rdr[0].ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                // Close connection
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            // Return Value
            if (sqlValue == "")
                return false;
            else
                return true;
        }



    }
}
